/**
 * Structured output contract for the AI model. The model is instructed
 * (see src/lib/prompts.ts) to return exactly this JSON shape so the UI
 * can render it deterministically.
 */
export type RiskLevel = 'Low' | 'Medium' | 'High' | 'Critical';

export type ProjectHealthStatus = 'Healthy' | 'Attention Needed' | 'Critical';

export type RiskCategory =
  | 'Budget'
  | 'Timeline'
  | 'Scope'
  | 'Stakeholder'
  | 'Resource'
  | 'Dependency'
  | 'Delivery'
  | 'Governance';

/** 1-5 scale used for both probability and impact ratings. */
export type RatingScale = 1 | 2 | 3 | 4 | 5;

export interface TopRisk {
  title: string;
  category: RiskCategory;
  description: string;
  probability: RatingScale;
  impact: RatingScale;
  severity: RiskLevel;
  recommendation: string;
}

export interface RiskAnalysisResult {
  overallRiskScore: number; // 0-100
  riskLevel: RiskLevel;
  executiveSummary: string;
  topRisks: TopRisk[];
  projectHealth: ProjectHealthStatus;
  nextActions: string[];
}

/** Client-side request/response wrapper states for the analysis flow. */
export type AnalysisStatus = 'idle' | 'loading' | 'success' | 'error';
