/**
 * Shape of the project intake form. This is the raw data collected from the
 * user before it's sent to the AI model for analysis.
 */
export type Methodology = 'Agile' | 'Waterfall' | 'Hybrid';

export type ProjectType =
  | 'Software Development'
  | 'Infrastructure / IT'
  | 'Construction'
  | 'Marketing Campaign'
  | 'Product Launch'
  | 'Process Improvement'
  | 'Research & Development'
  | 'Organizational Change'
  | 'Other';

export interface ProjectInput {
  projectName: string;
  projectType: ProjectType;
  budget: number; // in USD
  timelineWeeks: number;
  teamSize: number;
  complexity: number; // 1-5
  stakeholderCount: number;
  externalDependencies: number;
  methodology: Methodology;
  additionalNotes: string;
}

export const PROJECT_TYPES: ProjectType[] = [
  'Software Development',
  'Infrastructure / IT',
  'Construction',
  'Marketing Campaign',
  'Product Launch',
  'Process Improvement',
  'Research & Development',
  'Organizational Change',
  'Other',
];

export const METHODOLOGIES: Methodology[] = ['Agile', 'Waterfall', 'Hybrid'];

export const EMPTY_PROJECT_INPUT: ProjectInput = {
  projectName: '',
  projectType: 'Software Development',
  budget: 100000,
  timelineWeeks: 12,
  teamSize: 6,
  complexity: 3,
  stakeholderCount: 4,
  externalDependencies: 2,
  methodology: 'Agile',
  additionalNotes: '',
};
