import { complexityLabel } from '@/utils/riskUtils';

interface ComplexitySliderProps {
  value: number;
  onChange: (value: number) => void;
}

export function ComplexitySlider({ value, onChange }: ComplexitySliderProps) {
  const percent = ((value - 1) / 4) * 100;

  return (
    <div>
      <div className="mb-1.5 flex items-baseline justify-between">
        <span className="text-sm font-semibold text-text-primary">Complexity</span>
        <span className="text-xs font-semibold text-primary">{complexityLabel(value)}</span>
      </div>
      <div className="rounded-xl border border-border bg-surface-raised px-4 py-4">
        <input
          type="range"
          min={1}
          max={5}
          step={1}
          value={value}
          onChange={(e) => onChange(Number(e.target.value))}
          className="w-full accent-primary"
          style={{
            background: `linear-gradient(to right, rgb(var(--color-primary)) ${percent}%, rgb(var(--color-border)) ${percent}%)`,
            height: '6px',
            borderRadius: '999px',
            appearance: 'none',
            cursor: 'pointer',
          }}
          aria-label="Project complexity"
        />
        <div className="mt-2 flex justify-between text-[11px] text-text-faint">
          <span>Very Simple</span>
          <span>Moderate</span>
          <span>Very Complex</span>
        </div>
      </div>
    </div>
  );
}
