import React, { useState } from 'react';
import { EMPTY_PROJECT_INPUT, METHODOLOGIES, PROJECT_TYPES, ProjectInput } from '@/types/project';
import { FormFieldWrapper, Select, TextArea, TextInput } from './FormField';
import { ComplexitySlider } from './ComplexitySlider';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';

interface ProjectFormProps {
  onAnalyze: (input: ProjectInput) => void;
  isLoading: boolean;
  isDemoMode?: boolean;
}

export function ProjectForm({ onAnalyze, isLoading, isDemoMode }: ProjectFormProps) {
  const [form, setForm] = useState<ProjectInput>(EMPTY_PROJECT_INPUT);
  const [touched, setTouched] = useState(false);

  const isValid = form.projectName.trim().length > 0 && form.budget > 0 && form.timelineWeeks > 0 && form.teamSize > 0;

  const update = <K extends keyof ProjectInput>(key: K, value: ProjectInput[K]) => {
    setForm((prev) => ({ ...prev, [key]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setTouched(true);
    if (!isValid || isLoading) return;
    onAnalyze(form);
  };

  return (
    <Card className="animate-fade-in" padded={false}>
      <form onSubmit={handleSubmit} className="p-6 sm:p-8">
        <div className="mb-7">
          <h2 className="text-xl font-bold tracking-tight">Project Details</h2>
          <p className="mt-1 text-sm text-text-muted">
            Provide the essentials — our AI PMO consultant handles the rest.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
          <div className="sm:col-span-2">
            <FormFieldWrapper label="Project Name" required>
              <TextInput
                value={form.projectName}
                onChange={(e) => update('projectName', e.target.value)}
                placeholder="e.g. Customer Portal Redesign"
                required
              />
            </FormFieldWrapper>
            {touched && !form.projectName.trim() && (
              <p className="mt-1 text-xs text-risk-critical">Project name is required.</p>
            )}
          </div>

          <FormFieldWrapper label="Project Type">
            <Select value={form.projectType} onChange={(e) => update('projectType', e.target.value as ProjectInput['projectType'])}>
              {PROJECT_TYPES.map((type) => (
                <option key={type} value={type}>
                  {type}
                </option>
              ))}
            </Select>
          </FormFieldWrapper>

          <FormFieldWrapper label="Methodology">
            <Select value={form.methodology} onChange={(e) => update('methodology', e.target.value as ProjectInput['methodology'])}>
              {METHODOLOGIES.map((m) => (
                <option key={m} value={m}>
                  {m}
                </option>
              ))}
            </Select>
          </FormFieldWrapper>

          <FormFieldWrapper label="Budget" hint="USD">
            <TextInput
              type="number"
              min={0}
              step={1000}
              value={form.budget}
              onChange={(e) => update('budget', Number(e.target.value))}
            />
          </FormFieldWrapper>

          <FormFieldWrapper label="Timeline" hint="weeks">
            <TextInput
              type="number"
              min={1}
              value={form.timelineWeeks}
              onChange={(e) => update('timelineWeeks', Number(e.target.value))}
            />
          </FormFieldWrapper>

          <FormFieldWrapper label="Team Size" hint="people">
            <TextInput
              type="number"
              min={1}
              value={form.teamSize}
              onChange={(e) => update('teamSize', Number(e.target.value))}
            />
          </FormFieldWrapper>

          <FormFieldWrapper label="Number of Stakeholders">
            <TextInput
              type="number"
              min={0}
              value={form.stakeholderCount}
              onChange={(e) => update('stakeholderCount', Number(e.target.value))}
            />
          </FormFieldWrapper>

          <div className="sm:col-span-2">
            <FormFieldWrapper label="Number of External Dependencies" hint="vendors, systems, other teams">
              <TextInput
                type="number"
                min={0}
                value={form.externalDependencies}
                onChange={(e) => update('externalDependencies', Number(e.target.value))}
              />
            </FormFieldWrapper>
          </div>

          <div className="sm:col-span-2">
            <ComplexitySlider value={form.complexity} onChange={(v) => update('complexity', v)} />
          </div>

          <div className="sm:col-span-2">
            <FormFieldWrapper label="Additional Notes" hint="optional">
              <TextArea
                rows={4}
                value={form.additionalNotes}
                onChange={(e) => update('additionalNotes', e.target.value)}
                placeholder="Anything else the consultant should know — constraints, prior incidents, key concerns..."
              />
            </FormFieldWrapper>
          </div>
        </div>

        <div className="mt-8 flex items-center justify-between border-t border-border pt-6">
          <p className="hidden text-xs text-text-faint sm:flex sm:items-center sm:gap-1.5">
            {isDemoMode && (
              <span className="inline-flex items-center gap-1 rounded-full bg-primary/10 px-2 py-0.5 font-semibold text-primary">
                Demo Mode
              </span>
            )}
            {isDemoMode
              ? 'No API key connected — generating a realistic sample report.'
              : 'Analysis typically takes 10–20 seconds.'}
          </p>
          <Button type="submit" size="lg" isLoading={isLoading} className="w-full sm:w-auto">
            {!isLoading && (
              <svg className="h-[18px] w-[18px]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M13 10V3L4 14h7v7l9-11h-7z"
                />
              </svg>
            )}
            {isLoading ? 'Analyzing Project...' : 'Analyze Project'}
          </Button>
        </div>
      </form>
    </Card>
  );
}
