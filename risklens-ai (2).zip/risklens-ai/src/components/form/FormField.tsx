import React from 'react';

interface FormFieldWrapperProps {
  label: string;
  hint?: string;
  children: React.ReactNode;
  required?: boolean;
}

/** Shared label + hint wrapper so every field in the form looks consistent. */
export function FormFieldWrapper({ label, hint, children, required }: FormFieldWrapperProps) {
  return (
    <div>
      <label className="mb-1.5 flex items-baseline justify-between">
        <span className="text-sm font-semibold text-text-primary">
          {label}
          {required && <span className="ml-1 text-primary">*</span>}
        </span>
        {hint && <span className="text-xs text-text-faint">{hint}</span>}
      </label>
      {children}
    </div>
  );
}

const inputBase =
  'w-full rounded-xl border border-border bg-surface-raised px-3.5 py-2.5 text-sm text-text-primary placeholder:text-text-faint transition-colors focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20';

export function TextInput(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return <input {...props} className={`${inputBase} ${props.className || ''}`} />;
}

export function TextArea(props: React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea {...props} className={`${inputBase} resize-none ${props.className || ''}`} />;
}

export function Select({ children, ...props }: React.SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <div className="relative">
      <select
        {...props}
        className={`${inputBase} appearance-none pr-9 ${props.className || ''}`}
      >
        {children}
      </select>
      <svg
        className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-text-faint"
        fill="none"
        viewBox="0 0 24 24"
        stroke="currentColor"
      >
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
      </svg>
    </div>
  );
}
