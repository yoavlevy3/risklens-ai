import React from 'react';

type Tone = 'low' | 'medium' | 'high' | 'critical' | 'neutral' | 'primary';

const toneClasses: Record<Tone, string> = {
  low: 'bg-risk-low/10 text-risk-low border-risk-low/25',
  medium: 'bg-risk-medium/10 text-risk-medium border-risk-medium/25',
  high: 'bg-risk-high/10 text-risk-high border-risk-high/25',
  critical: 'bg-risk-critical/10 text-risk-critical border-risk-critical/25',
  neutral: 'bg-text-faint/10 text-text-muted border-border',
  primary: 'bg-primary/10 text-primary border-primary/25',
};

interface BadgeProps {
  tone?: Tone;
  children: React.ReactNode;
  icon?: React.ReactNode;
  className?: string;
}

export function Badge({ tone = 'neutral', children, icon, className = '' }: BadgeProps) {
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-semibold ${toneClasses[tone]} ${className}`}
    >
      {icon}
      {children}
    </span>
  );
}
