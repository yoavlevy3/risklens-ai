import React from 'react';

interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  hoverable?: boolean;
  padded?: boolean;
}

/** Base surface card used throughout the app: rounded corners, soft shadow, subtle border. */
export function Card({ hoverable, padded = true, className = '', children, ...props }: CardProps) {
  return (
    <div
      className={`rounded-2xl border border-border bg-surface shadow-soft ${padded ? 'p-6' : ''} ${
        hoverable ? 'transition-all duration-200 hover:shadow-soft-lg hover:border-text-faint/40 hover:-translate-y-0.5' : ''
      } ${className}`}
      {...props}
    >
      {children}
    </div>
  );
}
