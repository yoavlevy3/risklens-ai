import { useState } from 'react';
import { AiProvider } from '@/services/aiService';
import { Button } from '@/components/ui/Button';

interface ApiKeyModalProps {
  isOpen: boolean;
  onClose: () => void;
  provider: AiProvider;
  apiKey: string;
  onSave: (provider: AiProvider, apiKey: string) => void;
}

interface ProviderMeta {
  id: AiProvider;
  label: string;
  keyPlaceholder: string;
  portalLabel: string;
}

const PROVIDERS: ProviderMeta[] = [
  { id: 'anthropic', label: 'Claude (Anthropic)', keyPlaceholder: 'sk-ant-...', portalLabel: 'console.anthropic.com' },
  { id: 'openai', label: 'OpenAI', keyPlaceholder: 'sk-...', portalLabel: 'platform.openai.com' },
  { id: 'gemini', label: 'Google Gemini', keyPlaceholder: 'AIza...', portalLabel: 'aistudio.google.com/apikey' },
];

export function ApiKeyModal({ isOpen, onClose, provider, apiKey, onSave }: ApiKeyModalProps) {
  const [localProvider, setLocalProvider] = useState<AiProvider>(provider);
  const [localKey, setLocalKey] = useState(apiKey);
  const [showKey, setShowKey] = useState(false);

  if (!isOpen) return null;

  const activeMeta = PROVIDERS.find((p) => p.id === localProvider) || PROVIDERS[0];

  const handleSave = () => {
    onSave(localProvider, localKey.trim());
    onClose();
  };

  const handleUseDemoMode = () => {
    onSave(localProvider, '');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div
        className="absolute inset-0 bg-black/50 backdrop-blur-sm animate-fade-in"
        onClick={onClose}
        aria-hidden
      />
      <div className="relative w-full max-w-md rounded-2xl border border-border bg-surface p-6 shadow-soft-lg animate-fade-in">
        <div className="mb-5 flex items-start justify-between">
          <div>
            <h2 className="text-lg font-bold">Connect your AI provider</h2>
            <p className="mt-1 text-sm text-text-muted">
              RiskLens AI runs entirely in your browser — your key is stored only in this device's local storage
              and is sent directly to your chosen provider.
            </p>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1 text-text-muted hover:bg-surface-raised hover:text-text-primary"
            aria-label="Close"
          >
            <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="mb-4">
          <label className="mb-2 block text-xs font-semibold uppercase tracking-wide text-text-muted">
            Provider
          </label>
          <div className="grid grid-cols-3 gap-2">
            {PROVIDERS.map((p) => (
              <button
                key={p.id}
                onClick={() => setLocalProvider(p.id)}
                className={`rounded-xl border px-3 py-2.5 text-sm font-medium transition-colors ${
                  localProvider === p.id
                    ? 'border-primary bg-primary/10 text-primary'
                    : 'border-border text-text-muted hover:border-text-faint/50'
                }`}
              >
                {p.label}
              </button>
            ))}
          </div>
        </div>

        <div className="mb-2">
          <label className="mb-2 block text-xs font-semibold uppercase tracking-wide text-text-muted">
            API Key
          </label>
          <div className="relative">
            <input
              type={showKey ? 'text' : 'password'}
              value={localKey}
              onChange={(e) => setLocalKey(e.target.value)}
              placeholder={activeMeta.keyPlaceholder}
              className="w-full rounded-xl border border-border bg-surface-raised px-3.5 py-2.5 pr-16 text-sm font-mono placeholder:text-text-faint focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20"
            />
            <button
              onClick={() => setShowKey((s) => !s)}
              className="absolute right-2 top-1/2 -translate-y-1/2 rounded-lg px-2 py-1 text-xs font-medium text-text-muted hover:bg-surface hover:text-text-primary"
            >
              {showKey ? 'Hide' : 'Show'}
            </button>
          </div>
        </div>

        <p className="mb-5 text-xs text-text-faint">
          Get a key from <span className="font-medium text-text-muted">{activeMeta.portalLabel}</span>. Keys never
          leave your browser except to reach the provider you selected.
        </p>

        <div className="mb-5 flex items-start gap-2 rounded-xl border border-border bg-surface-raised px-3.5 py-3">
          <svg className="mt-0.5 h-4 w-4 shrink-0 text-text-faint" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
            />
          </svg>
          <p className="text-xs text-text-muted">
            Don't have a key handy?{' '}
            <button onClick={handleUseDemoMode} className="font-semibold text-primary hover:underline">
              Continue in Demo Mode
            </button>{' '}
            to explore RiskLens AI with realistic sample data instead.
          </p>
        </div>

        <div className="flex gap-2">
          <Button variant="secondary" onClick={onClose} className="flex-1">
            Cancel
          </Button>
          <Button variant="primary" onClick={handleSave} disabled={!localKey.trim()} className="flex-1">
            Save & Continue
          </Button>
        </div>
      </div>
    </div>
  );
}
