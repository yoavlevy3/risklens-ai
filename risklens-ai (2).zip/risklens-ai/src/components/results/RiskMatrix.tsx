import { TopRisk } from '@/types/risk';
import { Card } from '@/components/ui/Card';

interface RiskMatrixProps {
  risks: TopRisk[];
}

/** Returns a cell's background intensity token based on its position in the 5x5 grid. */
function cellTone(probability: number, impact: number): string {
  const score = probability * impact;
  if (score >= 20) return 'bg-risk-critical/25 border-risk-critical/40';
  if (score >= 12) return 'bg-risk-high/20 border-risk-high/35';
  if (score >= 6) return 'bg-risk-medium/15 border-risk-medium/30';
  return 'bg-risk-low/10 border-risk-low/25';
}

export function RiskMatrix({ risks }: RiskMatrixProps) {
  // Group risks by (probability, impact) cell so multiple risks landing on
  // the same cell stack as numbered chips rather than overlapping.
  const grid: Record<string, TopRisk[]> = {};
  risks.forEach((risk) => {
    const key = `${risk.probability}-${risk.impact}`;
    grid[key] = grid[key] ? [...grid[key], risk] : [risk];
  });

  // Rows = impact, descending from 5 (top) to 1 (bottom). Columns = probability 1-5.
  const impactLevels = [5, 4, 3, 2, 1];
  const probabilityLevels = [1, 2, 3, 4, 5];

  return (
    <Card className="animate-fade-in" hoverable>
      <div className="mb-5">
        <h3 className="text-base font-bold tracking-tight">Risk Matrix</h3>
        <p className="mt-1 text-sm text-text-muted">Probability vs. Impact for all identified risks</p>
      </div>

      <div className="flex gap-3">
        <div className="flex flex-col items-center justify-center">
          <span className="mb-2 whitespace-nowrap text-[11px] font-semibold uppercase tracking-wide text-text-faint [writing-mode:vertical-rl] rotate-180">
            Impact →
          </span>
        </div>

        <div className="flex-1">
          <div className="grid grid-cols-5 gap-1.5">
            {impactLevels.map((impact) =>
              probabilityLevels.map((probability) => {
                const key = `${probability}-${impact}`;
                const cellRisks = grid[key] || [];
                return (
                  <div
                    key={key}
                    className={`relative flex aspect-square min-h-[52px] items-center justify-center rounded-lg border transition-transform hover:scale-105 ${cellTone(
                      probability,
                      impact
                    )}`}
                    title={cellRisks.map((r) => r.title).join(', ')}
                  >
                    {cellRisks.length > 0 && (
                      <div className="flex flex-wrap items-center justify-center gap-1 p-1">
                        {cellRisks.map((r, i) => (
                          <span
                            key={i}
                            className="flex h-6 w-6 items-center justify-center rounded-full bg-surface text-[11px] font-bold text-text-primary shadow-soft"
                          >
                            {risks.indexOf(r) + 1}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>
          <div className="mt-2 grid grid-cols-5 gap-1.5">
            {probabilityLevels.map((p) => (
              <span key={p} className="text-center text-[11px] text-text-faint">
                {p}
              </span>
            ))}
          </div>
          <p className="mt-1 text-center text-[11px] font-semibold uppercase tracking-wide text-text-faint">
            Probability →
          </p>
        </div>
      </div>

      <div className="mt-5 flex flex-wrap gap-x-4 gap-y-2 border-t border-border pt-4">
        {risks.map((risk, i) => (
          <div key={i} className="flex items-center gap-1.5 text-xs text-text-muted">
            <span className="flex h-[18px] w-[18px] items-center justify-center rounded-full bg-surface-raised text-[10px] font-bold">
              {i + 1}
            </span>
            {risk.title}
          </div>
        ))}
      </div>
    </Card>
  );
}
