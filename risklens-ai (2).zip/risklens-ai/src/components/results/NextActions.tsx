import { useState } from 'react';
import { Card } from '@/components/ui/Card';

interface NextActionsProps {
  actions: string[];
}

export function NextActions({ actions }: NextActionsProps) {
  const [checked, setChecked] = useState<Set<number>>(new Set());

  const toggle = (i: number) => {
    setChecked((prev) => {
      const next = new Set(prev);
      if (next.has(i)) next.delete(i);
      else next.add(i);
      return next;
    });
  };

  const completedCount = checked.size;

  return (
    <Card className="animate-fade-in" hoverable>
      <div className="mb-4 flex items-center justify-between">
        <h3 className="text-base font-bold tracking-tight">Next Actions</h3>
        <span className="text-xs font-medium text-text-faint">
          {completedCount}/{actions.length} done
        </span>
      </div>
      <ul className="space-y-2">
        {actions.map((action, i) => {
          const isChecked = checked.has(i);
          return (
            <li key={i}>
              <button
                onClick={() => toggle(i)}
                className="flex w-full items-start gap-3 rounded-xl px-3 py-2.5 text-left transition-colors hover:bg-surface-raised"
              >
                <span
                  className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-md border-2 transition-colors ${
                    isChecked ? 'border-primary bg-primary' : 'border-border'
                  }`}
                >
                  {isChecked && (
                    <svg className="h-3 w-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                    </svg>
                  )}
                </span>
                <span
                  className={`text-sm leading-snug transition-colors ${
                    isChecked ? 'text-text-faint line-through' : 'text-text-primary'
                  }`}
                >
                  {action}
                </span>
              </button>
            </li>
          );
        })}
      </ul>
    </Card>
  );
}
