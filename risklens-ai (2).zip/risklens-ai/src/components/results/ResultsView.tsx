import { useRef, useState } from 'react';
import { RiskAnalysisResult } from '@/types/risk';
import { ProjectInput } from '@/types/project';
import { RiskScoreCard } from './RiskScoreCard';
import { ExecutiveSummary } from './ExecutiveSummary';
import { RiskCard } from './RiskCard';
import { RiskMatrix } from './RiskMatrix';
import { NextActions } from './NextActions';
import { ProjectHealth } from './ProjectHealth';
import { Button } from '@/components/ui/Button';
import { buildTextReport, downloadTextFile, exportElementToPdf } from '@/utils/pdfExport';

interface ResultsViewProps {
  result: RiskAnalysisResult;
  project: ProjectInput;
  isDemo?: boolean;
  onAnalyzeAnother: () => void;
  onOpenApiSettings?: () => void;
}

export function ResultsView({ result, project, isDemo, onAnalyzeAnother, onOpenApiSettings }: ResultsViewProps) {
  const reportRef = useRef<HTMLDivElement>(null);
  const [isExporting, setIsExporting] = useState(false);

  const handleExportPdf = async () => {
    if (!reportRef.current) return;
    setIsExporting(true);
    try {
      await exportElementToPdf(reportRef.current, `${project.projectName || 'risk-report'}-risklens.pdf`);
    } finally {
      setIsExporting(false);
    }
  };

  const handleDownloadReport = () => {
    const text = buildTextReport({
      projectName: project.projectName || 'Untitled Project',
      generatedAt: new Date(),
      overallRiskScore: result.overallRiskScore,
      riskLevel: result.riskLevel,
      projectHealth: result.projectHealth,
      executiveSummary: result.executiveSummary,
      isDemo,
      topRisks: result.topRisks,
      nextActions: result.nextActions,
    });
    downloadTextFile(text, `${project.projectName || 'risk-report'}-risklens.txt`);
  };

  return (
    <div ref={reportRef} className="pdf-report space-y-6">
      {isDemo && (
        <div className="no-print print:hidden flex flex-col items-start gap-3 rounded-2xl border border-primary/25 bg-primary/5 px-5 py-4 sm:flex-row sm:items-center sm:justify-between animate-fade-in">
          <div className="flex items-start gap-3">
            <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary/15 text-primary">
              <svg className="h-3.5 w-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                />
              </svg>
            </span>
            <div>
              <span className="text-sm font-bold text-text-primary">Demo Mode — sample report</span>
              <p className="text-xs text-text-muted">
                This analysis was generated from your inputs using RiskLens AI's built-in demo data, not a live AI
                model. Connect an API key for a genuine AI-driven assessment.
              </p>
            </div>
          </div>
          {onOpenApiSettings && (
            <Button variant="secondary" size="sm" onClick={onOpenApiSettings} className="shrink-0">
              Connect API Key
            </Button>
          )}
        </div>
      )}

      {/* Title stays visible in both the on-screen view and the PDF export;
          only the action-button group is excluded from the export (see
          exportElementToPdf's ignoreElements, keyed off .no-print below). */}
      <div className="pdf-avoid-break flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">{project.projectName || 'Untitled Project'}</h1>
          <p className="mt-1 text-sm text-text-muted">
            {project.projectType} · {project.methodology} · Analyzed {new Date().toLocaleDateString()}
            {isDemo && ' · Demo Mode sample data'}
          </p>
        </div>
        <div className="no-print print:hidden flex flex-wrap gap-2">
          <Button variant="secondary" size="sm" onClick={handleDownloadReport}>
            <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
              />
            </svg>
            Download Report
          </Button>
          <Button variant="secondary" size="sm" onClick={handleExportPdf} isLoading={isExporting}>
            {!isExporting && (
              <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                />
              </svg>
            )}
            Export PDF
          </Button>
          <Button variant="primary" size="sm" onClick={onAnalyzeAnother}>
            <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
            </svg>
            Analyze Another
          </Button>
        </div>
      </div>

      {/* Report body — always part of the export, with padding so the PDF
          page doesn't butt content against its edges. */}
      <div className="space-y-6 rounded-3xl bg-bg p-8">
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
          <div className="pdf-avoid-break lg:col-span-2">
            <RiskScoreCard score={result.overallRiskScore} riskLevel={result.riskLevel} />
          </div>
          <div className="pdf-avoid-break">
            <ProjectHealth status={result.projectHealth} />
          </div>
        </div>

        <div className="pdf-avoid-break">
          <ExecutiveSummary summary={result.executiveSummary} />
        </div>

        <div>
          <h2 className="mb-4 text-lg font-bold tracking-tight">Top Risks</h2>
          <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
            {result.topRisks.map((risk, i) => (
              <div key={i} className="pdf-avoid-break">
                <RiskCard risk={risk} index={i} />
              </div>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          <div className="pdf-avoid-break">
            <RiskMatrix risks={result.topRisks} />
          </div>
          <div className="pdf-avoid-break">
            <NextActions actions={result.nextActions} />
          </div>
        </div>
      </div>
    </div>
  );
}
