import { ProjectHealthStatus } from '@/types/risk';
import { Card } from '@/components/ui/Card';

interface ProjectHealthProps {
  status: ProjectHealthStatus;
}

const config: Record<
  ProjectHealthStatus,
  { colorClass: string; bgClass: string; borderClass: string; icon: JSX.Element; description: string }
> = {
  Healthy: {
    colorClass: 'text-risk-low',
    bgClass: 'bg-risk-low/10',
    borderClass: 'border-risk-low/25',
    description: 'On track with no significant blockers.',
    icon: (
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
    ),
  },
  'Attention Needed': {
    colorClass: 'text-risk-medium',
    bgClass: 'bg-risk-medium/10',
    borderClass: 'border-risk-medium/25',
    description: 'Some areas need proactive management this cycle.',
    icon: (
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth={2}
        d="M12 9v3.75m9-.75a9 9 0 11-18 0 9 9 0 0118 0zm-9 3.75h.008v.008H12v-.008z"
      />
    ),
  },
  Critical: {
    colorClass: 'text-risk-critical',
    bgClass: 'bg-risk-critical/10',
    borderClass: 'border-risk-critical/25',
    description: 'Requires immediate executive intervention.',
    icon: (
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth={2}
        d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z"
      />
    ),
  },
};

export function ProjectHealth({ status }: ProjectHealthProps) {
  const c = config[status];
  return (
    <Card className="animate-fade-in" hoverable>
      <h3 className="mb-4 text-base font-bold tracking-tight">Project Health</h3>
      <div className={`flex items-center gap-4 rounded-xl border px-4 py-4 ${c.bgClass} ${c.borderClass}`}>
        <div className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-surface ${c.colorClass}`}>
          <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            {c.icon}
          </svg>
        </div>
        <div>
          <span className={`block text-[15px] font-bold ${c.colorClass}`}>{status}</span>
          <span className="text-xs text-text-muted">{c.description}</span>
        </div>
      </div>
    </Card>
  );
}
