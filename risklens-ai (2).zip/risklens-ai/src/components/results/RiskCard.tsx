import { TopRisk } from '@/types/risk';
import { ratingLabel, riskLevelToToken } from '@/utils/riskUtils';
import { Badge } from '@/components/ui/Badge';
import { Card } from '@/components/ui/Card';

interface RiskCardProps {
  risk: TopRisk;
  index: number;
}

const categoryIcons: Record<string, string> = {
  Budget: 'M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V6m0 10v2',
  Timeline: 'M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z',
  Scope: 'M9 3v2m6-2v2M4 8h16M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8H5z',
  Stakeholder: 'M17 20h5v-2a4 4 0 00-3-3.87M9 20H4v-2a4 4 0 013-3.87m9-6.13a4 4 0 11-8 0 4 4 0 018 0z',
  Resource: 'M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4',
  Dependency: 'M13.828 10.172a4 4 0 010 5.656l-3 3a4 4 0 01-5.656-5.656l1.5-1.5m4.656 1.5a4 4 0 010-5.656l3-3a4 4 0 115.656 5.656l-1.5 1.5',
  Delivery: 'M9 17V7m0 10a2 2 0 01-2 2H5a2 2 0 01-2-2V7a2 2 0 012-2h2a2 2 0 012 2m0 10a2 2 0 002 2h2a2 2 0 002-2M9 7a2 2 0 012-2h2a2 2 0 012 2m0 10V7m0 10a2 2 0 002 2h2a2 2 0 002-2V7a2 2 0 00-2-2h-2a2 2 0 00-2 2',
  Governance: 'M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z',
};

// Static class lookups so Tailwind's compiler can detect every class at build time
// (template-literal interpolation like `bg-risk-${tone}` would not be picked up).
const iconWrapClasses: Record<string, string> = {
  low: 'bg-risk-low/10',
  medium: 'bg-risk-medium/10',
  high: 'bg-risk-high/10',
  critical: 'bg-risk-critical/10',
};
const iconColorClasses: Record<string, string> = {
  low: 'text-risk-low',
  medium: 'text-risk-medium',
  high: 'text-risk-high',
  critical: 'text-risk-critical',
};
const barFillClasses: Record<string, string> = {
  low: 'bg-risk-low',
  medium: 'bg-risk-medium',
  high: 'bg-risk-high',
  critical: 'bg-risk-critical',
};

export function RiskCard({ risk, index }: RiskCardProps) {
  const tone = riskLevelToToken(risk.severity);
  const iconPath = categoryIcons[risk.category] || categoryIcons.Governance;

  return (
    <Card className="animate-fade-in" hoverable style={{ animationDelay: `${index * 60}ms` }}>
      <div className="mb-3 flex items-start justify-between gap-3">
        <div className="flex items-start gap-3">
          <div className={`mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-lg ${iconWrapClasses[tone]}`}>
            <svg className={`h-[18px] w-[18px] ${iconColorClasses[tone]}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d={iconPath} />
            </svg>
          </div>
          <div>
            <span className="text-[11px] font-semibold uppercase tracking-wide text-text-faint">
              {risk.category}
            </span>
            <h4 className="text-[15px] font-bold leading-snug">{risk.title}</h4>
          </div>
        </div>
        <Badge tone={tone}>{risk.severity}</Badge>
      </div>

      <p className="mb-4 text-sm leading-relaxed text-text-muted">{risk.description}</p>

      <div className="mb-4 grid grid-cols-2 gap-3">
        <div className="rounded-xl bg-surface-raised px-3 py-2.5">
          <div className="mb-1 flex items-center justify-between">
            <span className="text-[11px] font-semibold text-text-faint">PROBABILITY</span>
            <span className="text-xs font-bold">{risk.probability}/5</span>
          </div>
          <div className="flex gap-1">
            {[1, 2, 3, 4, 5].map((n) => (
              <span
                key={n}
                className={`h-1.5 flex-1 rounded-full ${n <= risk.probability ? barFillClasses[tone] : 'bg-border'}`}
              />
            ))}
          </div>
          <span className="mt-1 block text-[11px] text-text-faint">{ratingLabel(risk.probability)}</span>
        </div>
        <div className="rounded-xl bg-surface-raised px-3 py-2.5">
          <div className="mb-1 flex items-center justify-between">
            <span className="text-[11px] font-semibold text-text-faint">IMPACT</span>
            <span className="text-xs font-bold">{risk.impact}/5</span>
          </div>
          <div className="flex gap-1">
            {[1, 2, 3, 4, 5].map((n) => (
              <span
                key={n}
                className={`h-1.5 flex-1 rounded-full ${n <= risk.impact ? barFillClasses[tone] : 'bg-border'}`}
              />
            ))}
          </div>
          <span className="mt-1 block text-[11px] text-text-faint">{ratingLabel(risk.impact)}</span>
        </div>
      </div>

      <div className="rounded-xl border border-primary/20 bg-primary/5 px-3.5 py-3">
        <span className="mb-1 block text-[11px] font-semibold uppercase tracking-wide text-primary">
          Recommendation
        </span>
        <p className="text-sm leading-relaxed text-text-primary/90">{risk.recommendation}</p>
      </div>
    </Card>
  );
}
