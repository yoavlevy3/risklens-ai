import { useEffect, useState } from 'react';
import { RiskLevel } from '@/types/risk';
import { riskLevelHex } from '@/utils/riskUtils';
import { useTheme } from '@/hooks/useTheme';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';

interface RiskScoreCardProps {
  score: number;
  riskLevel: RiskLevel;
}

const SIZE = 200;
const STROKE = 14;
const RADIUS = (SIZE - STROKE) / 2;
const CIRCUMFERENCE = 2 * Math.PI * RADIUS;

export function RiskScoreCard({ score, riskLevel }: RiskScoreCardProps) {
  const { theme } = useTheme();
  const [animatedScore, setAnimatedScore] = useState(0);
  const color = riskLevelHex(riskLevel, theme === 'dark');

  useEffect(() => {
    // Animate the score count-up + arc fill on mount / score change.
    let raf: number;
    const duration = 900;
    const start = performance.now();
    const tick = (now: number) => {
      const progress = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setAnimatedScore(Math.round(eased * score));
      if (progress < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [score]);

  const offset = CIRCUMFERENCE - (animatedScore / 100) * CIRCUMFERENCE;

  const levelMessage: Record<RiskLevel, string> = {
    Low: 'This project shows a healthy risk profile.',
    Medium: 'Manageable risk — worth monitoring closely.',
    High: 'Elevated risk requiring active mitigation.',
    Critical: 'Severe risk exposure — immediate action needed.',
  };

  return (
    <Card className="animate-fade-in" hoverable>
      <div className="flex flex-col items-center gap-5 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative flex h-[200px] w-[200px] shrink-0 items-center justify-center">
          {/* Ambient rotating scan ring — the product's signature "analyzer" motif */}
          <svg
            className="absolute inset-0 animate-scan-sweep"
            viewBox={`0 0 ${SIZE} ${SIZE}`}
            style={{ opacity: 0.35 }}
          >
            <circle
              cx={SIZE / 2}
              cy={SIZE / 2}
              r={RADIUS + STROKE / 2 + 6}
              fill="none"
              stroke={color}
              strokeWidth={1.5}
              strokeDasharray="1 14"
              strokeLinecap="round"
            />
          </svg>

          <svg width={SIZE} height={SIZE} viewBox={`0 0 ${SIZE} ${SIZE}`} className="-rotate-90">
            <circle
              cx={SIZE / 2}
              cy={SIZE / 2}
              r={RADIUS}
              fill="none"
              stroke="rgb(var(--color-border))"
              strokeWidth={STROKE}
            />
            <circle
              cx={SIZE / 2}
              cy={SIZE / 2}
              r={RADIUS}
              fill="none"
              stroke={color}
              strokeWidth={STROKE}
              strokeLinecap="round"
              strokeDasharray={CIRCUMFERENCE}
              strokeDashoffset={offset}
              style={{ transition: 'stroke 0.3s ease' }}
            />
          </svg>

          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className="font-mono text-5xl font-bold tabular-nums" style={{ color }}>
              {animatedScore}
            </span>
            <span className="text-xs font-medium text-text-faint">out of 100</span>
          </div>
        </div>

        <div className="flex flex-1 flex-col items-center gap-2 text-center sm:items-start sm:text-left">
          <span className="text-xs font-semibold uppercase tracking-widest text-text-faint">
            Overall Risk Score
          </span>
          <Badge tone={riskLevel.toLowerCase() as 'low' | 'medium' | 'high' | 'critical'} className="text-sm">
            {riskLevel} Risk
          </Badge>
          <p className="mt-1 max-w-sm text-sm text-text-muted">{levelMessage[riskLevel]}</p>
        </div>
      </div>
    </Card>
  );
}
