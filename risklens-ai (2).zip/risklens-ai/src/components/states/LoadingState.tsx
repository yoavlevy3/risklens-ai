import { useEffect, useState } from 'react';

const steps = [
  'Reviewing project parameters...',
  'Assessing budget and timeline risk...',
  'Evaluating stakeholder and governance exposure...',
  'Cross-checking dependency and delivery risk...',
  'Drafting executive summary...',
];

const demoSteps = [
  'Reviewing project parameters...',
  'Generating a realistic sample analysis...',
  'Populating the risk matrix...',
  'Drafting executive summary...',
];

interface LoadingStateProps {
  isDemo?: boolean;
}

export function LoadingState({ isDemo }: LoadingStateProps) {
  const [stepIndex, setStepIndex] = useState(0);
  const activeSteps = isDemo ? demoSteps : steps;

  useEffect(() => {
    setStepIndex(0);
    const interval = setInterval(() => {
      setStepIndex((prev) => Math.min(prev + 1, activeSteps.length - 1));
    }, isDemo ? 700 : 2200);
    return () => clearInterval(interval);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isDemo]);

  return (
    <div className="flex h-full flex-col items-center justify-center rounded-2xl border border-border bg-surface px-8 py-16 text-center shadow-soft">
      <div className="relative mb-6 flex h-20 w-20 items-center justify-center">
        <svg className="absolute inset-0 animate-scan-sweep" viewBox="0 0 80 80">
          <circle
            cx="40"
            cy="40"
            r="34"
            fill="none"
            stroke="rgb(var(--color-primary))"
            strokeWidth="2"
            strokeDasharray="4 10"
            strokeLinecap="round"
          />
        </svg>
        <div className="flex h-14 w-14 items-center justify-center rounded-full bg-primary/10">
          <svg className="h-7 w-7 animate-pulse-soft text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={1.6}
              d="M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09zM18.259 8.715L18 9.75l-.259-1.035a3.375 3.375 0 00-2.455-2.456L14.25 6l1.036-.259a3.375 3.375 0 002.455-2.456L18 2.25l.259 1.035a3.375 3.375 0 002.456 2.456L21.75 6l-1.035.259a3.375 3.375 0 00-2.456 2.456z"
            />
          </svg>
        </div>
      </div>

      <h3 className="mb-2 text-base font-bold">{isDemo ? 'Generating demo analysis' : 'Analyzing your project'}</h3>
      <p className="text-sm text-text-muted transition-all">{activeSteps[stepIndex]}</p>

      <div className="mt-6 h-1 w-48 overflow-hidden rounded-full bg-border">
        <div className="h-full w-full animate-shimmer skeleton" />
      </div>
    </div>
  );
}
