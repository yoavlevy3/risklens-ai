import { Theme } from '@/hooks/useTheme';
import { ThemeToggle } from './ThemeToggle';
import { Button } from '@/components/ui/Button';

interface HeaderProps {
  theme: Theme;
  onToggleTheme: () => void;
  onOpenApiSettings: () => void;
  hasApiKey: boolean;
}

export function Header({ theme, onToggleTheme, onOpenApiSettings, hasApiKey }: HeaderProps) {
  return (
    <header className="sticky top-0 z-40 border-b border-border bg-bg/80 glass">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
        <div className="flex items-center gap-2.5">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary shadow-glow">
            <svg viewBox="0 0 24 24" className="h-[18px] w-[18px] text-white" fill="none">
              <path
                d="M12 2L3 6.5V12c0 5.25 3.6 10.15 9 11 5.4-.85 9-5.75 9-11V6.5L12 2z"
                fill="currentColor"
                fillOpacity="0.25"
              />
              <path
                d="M12 2L3 6.5V12c0 5.25 3.6 10.15 9 11 5.4-.85 9-5.75 9-11V6.5L12 2z"
                stroke="currentColor"
                strokeWidth="1.6"
                strokeLinejoin="round"
              />
              <path d="M9 12l2 2 4-4.5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>
          <span className="text-[15px] font-bold tracking-tight">
            RiskLens <span className="text-primary">AI</span>
          </span>
        </div>

        <div className="flex items-center gap-3">
          <Button
            variant="secondary"
            size="sm"
            onClick={onOpenApiSettings}
            icon={
              <span
                className={`h-1.5 w-1.5 rounded-full ${hasApiKey ? 'bg-risk-low' : 'bg-risk-medium'}`}
              />
            }
          >
            {hasApiKey ? 'API Connected' : 'Demo Mode'}
          </Button>
          <ThemeToggle theme={theme} onToggle={onToggleTheme} />
        </div>
      </div>
    </header>
  );
}
