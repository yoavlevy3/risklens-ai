import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

/**
 * html2canvas (and most rasterizers of its generation) only reliably parses
 * legacy comma-separated color syntax — `rgb(r, g, b)` / `rgba(r, g, b, a)`.
 * Tailwind's CSS-variable-driven palette in this project compiles to the
 * modern space+slash syntax (`rgb(var(--color-x) / <alpha>)`), which
 * html2canvas can fail to parse — the visible symptom is exactly what shows
 * up here: backgrounds, badges, and borders silently drop out and the
 * export renders washed out / white.
 *
 * The fix: before capture, tag every element in the export subtree with a
 * stable id, then in html2canvas's `onclone` hook look up each cloned
 * element's original by that id and copy over the browser's *computed*
 * colors (background, text, border, shadow) as inline styles.
 * `getComputedStyle` always normalizes to the legacy comma syntax
 * regardless of how the color was declared, so the clone html2canvas
 * actually rasterizes never touches a CSS variable or the modern color
 * syntax at all.
 *
 * IDs (rather than positional child-index matching) are required because
 * `ignoreElements` removes nodes from the clone, which would otherwise
 * desync a parallel index-based walk between the source and cloned trees.
 */
const PDF_NODE_ID_ATTR = 'data-pdf-node-id';

function tagElementsForExport(root: HTMLElement): Map<string, Element> {
  const idToElement = new Map<string, Element>();
  let counter = 0;
  const walk = (el: Element) => {
    const id = String(counter++);
    el.setAttribute(PDF_NODE_ID_ATTR, id);
    idToElement.set(id, el);
    for (const child of Array.from(el.children)) walk(child);
  };
  walk(root);
  return idToElement;
}

function untagElements(root: HTMLElement): void {
  root.removeAttribute(PDF_NODE_ID_ATTR);
  root.querySelectorAll(`[${PDF_NODE_ID_ATTR}]`).forEach((el) => el.removeAttribute(PDF_NODE_ID_ATTR));
}

const COLOR_PROPS = [
  'backgroundColor',
  'color',
  'borderTopColor',
  'borderRightColor',
  'borderBottomColor',
  'borderLeftColor',
  'boxShadow',
  'outlineColor',
] as const;

function inlineComputedColors(idToElement: Map<string, Element>, cloneRoot: Element): void {
  const cloneNodes = [cloneRoot, ...Array.from(cloneRoot.querySelectorAll(`[${PDF_NODE_ID_ATTR}]`))];
  for (const cloneEl of cloneNodes) {
    const id = cloneEl.getAttribute(PDF_NODE_ID_ATTR);
    const sourceEl = id ? idToElement.get(id) : undefined;
    if (!sourceEl) continue;

    const computed = window.getComputedStyle(sourceEl);
    const style = (cloneEl as HTMLElement).style;
    for (const prop of COLOR_PROPS) {
      const value = computed[prop as keyof CSSStyleDeclaration] as string;
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      if (value) (style as any)[prop] = value;
    }
    style.setProperty('-webkit-print-color-adjust', 'exact');
    style.setProperty('print-color-adjust', 'exact');
  }
}

/**
 * Renders a DOM node to a multi-page A4 PDF and triggers a download.
 * Used for both "Export to PDF" and "Download Risk Report".
 *
 * @param backgroundColor Fallback page background if the element's own
 *   computed background can't be resolved (e.g. transparent ancestors).
 *   Defaults to the app's light-mode surface color so exports never render
 *   on a jarring pure-white canvas.
 */
export async function exportElementToPdf(
  element: HTMLElement,
  fileName: string,
  backgroundColor = '#f8fafc'
): Promise<void> {
  const resolvedBackground = window.getComputedStyle(element).backgroundColor || backgroundColor;
  const idToElement = tagElementsForExport(element);

  let canvas: HTMLCanvasElement;
  try {
    canvas = await html2canvas(element, {
      scale: 2,
      useCORS: true,
      backgroundColor: resolvedBackground,
      // html2canvas doesn't evaluate @media print, so on-screen elements
      // marked .no-print (action buttons, demo banner) need to be
      // explicitly skipped here rather than relying on print CSS alone.
      ignoreElements: (el) => el.classList.contains('no-print'),
      onclone: (_doc, clonedElement) => {
        // Re-resolve every color as an explicit inline value on the clone
        // so html2canvas never has to parse a CSS variable or modern color
        // syntax — see the block comment above for why this is needed.
        inlineComputedColors(idToElement, clonedElement);
      },
    });
  } finally {
    untagElements(element);
  }

  const imgData = canvas.toDataURL('image/png');
  const pdf = new jsPDF('p', 'mm', 'a4');

  const pageWidth = pdf.internal.pageSize.getWidth();
  const pageHeight = pdf.internal.pageSize.getHeight();

  const imgWidth = pageWidth;
  const imgHeight = (canvas.height * imgWidth) / canvas.width;

  let heightLeft = imgHeight;
  let position = 0;

  pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
  heightLeft -= pageHeight;

  while (heightLeft > 0) {
    position = heightLeft - imgHeight;
    pdf.addPage();
    pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
    heightLeft -= pageHeight;
  }

  pdf.save(fileName);
}

/** Generates a plain-text risk report suitable for the "Download Risk Report" (.txt) action. */
export function buildTextReport(params: {
  projectName: string;
  generatedAt: Date;
  overallRiskScore: number;
  riskLevel: string;
  projectHealth: string;
  executiveSummary: string;
  isDemo?: boolean;
  topRisks: Array<{
    title: string;
    category: string;
    probability: number;
    impact: number;
    severity: string;
    description: string;
    recommendation: string;
  }>;
  nextActions: string[];
}): string {
  const lines: string[] = [];
  lines.push('RISKLENS AI — PROJECT RISK REPORT');
  lines.push('='.repeat(50));
  if (params.isDemo) {
    lines.push('[DEMO MODE — sample data generated locally, not a live AI model]');
  }
  lines.push(`Project: ${params.projectName}`);
  lines.push(`Generated: ${params.generatedAt.toLocaleString()}`);
  lines.push('');
  lines.push(`Overall Risk Score: ${params.overallRiskScore}/100`);
  lines.push(`Risk Level: ${params.riskLevel}`);
  lines.push(`Project Health: ${params.projectHealth}`);
  lines.push('');
  lines.push('EXECUTIVE SUMMARY');
  lines.push('-'.repeat(50));
  lines.push(params.executiveSummary);
  lines.push('');
  lines.push('TOP RISKS');
  lines.push('-'.repeat(50));
  params.topRisks.forEach((risk, i) => {
    lines.push(`${i + 1}. ${risk.title} [${risk.category}] — Severity: ${risk.severity}`);
    lines.push(`   Probability: ${risk.probability}/5  |  Impact: ${risk.impact}/5`);
    lines.push(`   ${risk.description}`);
    lines.push(`   Recommendation: ${risk.recommendation}`);
    lines.push('');
  });
  lines.push('NEXT ACTIONS');
  lines.push('-'.repeat(50));
  params.nextActions.forEach((action, i) => {
    lines.push(`[ ] ${i + 1}. ${action}`);
  });
  lines.push('');
  lines.push('Generated by RiskLens AI');
  return lines.join('\n');
}

export function downloadTextFile(content: string, fileName: string): void {
  const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
