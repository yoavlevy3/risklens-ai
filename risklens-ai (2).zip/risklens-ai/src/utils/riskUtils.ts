import { ProjectHealthStatus, RiskLevel } from '@/types/risk';

/** Maps a risk level to its semantic Tailwind color token (text/bg/border families use `risk-{key}`). */
export function riskLevelToToken(level: RiskLevel): 'low' | 'medium' | 'high' | 'critical' {
  switch (level) {
    case 'Low':
      return 'low';
    case 'Medium':
      return 'medium';
    case 'High':
      return 'high';
    case 'Critical':
      return 'critical';
  }
}

/** Derives a risk level purely from a 0-100 score, used as a fallback/sanity-check for AI output. */
export function scoreToRiskLevel(score: number): RiskLevel {
  if (score < 25) return 'Low';
  if (score < 50) return 'Medium';
  if (score < 75) return 'High';
  return 'Critical';
}

export function riskLevelHex(level: RiskLevel, isDark: boolean): string {
  const palette = {
    Low: isDark ? '#2FBF71' : '#28AF6E',
    Medium: isDark ? '#E5B93A' : '#D69E2E',
    High: isDark ? '#F2994A' : '#E87A37',
    Critical: isDark ? '#EF4444' : '#E03E3E',
  };
  return palette[level];
}

export function healthToToken(health: ProjectHealthStatus): 'low' | 'medium' | 'critical' {
  switch (health) {
    case 'Healthy':
      return 'low';
    case 'Attention Needed':
      return 'medium';
    case 'Critical':
      return 'critical';
  }
}

/** Formats a currency amount for display, e.g. 125000 -> "$125,000". */
export function formatCurrency(value: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: 0,
  }).format(value);
}

/** Clamp a number between min and max. */
export function clamp(value: number, min: number, max: number): number {
  return Math.min(Math.max(value, min), max);
}

/** Human label for the 1-5 complexity slider. */
export function complexityLabel(value: number): string {
  const labels = ['Very Simple', 'Simple', 'Moderate', 'Complex', 'Very Complex'];
  return labels[clamp(value, 1, 5) - 1];
}

/** Human label for probability/impact 1-5 ratings used on risk cards. */
export function ratingLabel(value: number): string {
  const labels = ['Very Low', 'Low', 'Moderate', 'High', 'Very High'];
  return labels[clamp(value, 1, 5) - 1];
}
