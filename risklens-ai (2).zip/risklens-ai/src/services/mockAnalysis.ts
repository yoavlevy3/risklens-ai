import { ProjectInput } from '@/types/project';
import { RatingScale, RiskAnalysisResult, RiskCategory, RiskLevel, TopRisk } from '@/types/risk';
import { clamp, formatCurrency, scoreToRiskLevel } from '@/utils/riskUtils';

/**
 * Demo Mode data generator.
 *
 * When no API key is configured, RiskLens AI still needs to feel like a real
 * product during a walkthrough or showcase. This module produces a
 * comprehensive, professionally-written RiskAnalysisResult derived from the
 * actual project inputs (not random placeholder text), so every number and
 * recommendation on screen is plausibly grounded in what the user typed in.
 *
 * The heuristics here are intentionally simple and transparent — they exist
 * to make the UI look and feel real, not to replace genuine AI analysis.
 */

interface CategoryAssessment {
  category: RiskCategory;
  probability: RatingScale;
  impact: RatingScale;
  title: string;
  description: string;
  recommendation: string;
}

function toRating(value: number): RatingScale {
  return clamp(Math.round(value), 1, 5) as RatingScale;
}

function severityFromRatings(probability: number, impact: number): RiskLevel {
  const product = probability * impact; // 1-25
  if (product >= 20) return 'Critical';
  if (product >= 12) return 'High';
  if (product >= 6) return 'Medium';
  return 'Low';
}

function assessBudget(input: ProjectInput): CategoryAssessment {
  const costPerPersonWeek = input.budget / Math.max(input.teamSize * input.timelineWeeks, 1);

  let probability: number;
  if (costPerPersonWeek < 1200) probability = 5;
  else if (costPerPersonWeek < 2000) probability = 4;
  else if (costPerPersonWeek < 3200) probability = 3;
  else if (costPerPersonWeek < 5000) probability = 2;
  else probability = 1;

  let impact: number;
  if (input.budget >= 500000) impact = 5;
  else if (input.budget >= 200000) impact = 4;
  else if (input.budget >= 75000) impact = 3;
  else if (input.budget >= 25000) impact = 2;
  else impact = 1;

  const tight = probability >= 4;
  return {
    category: 'Budget',
    probability: toRating(probability),
    impact: toRating(impact),
    title: tight ? 'Constrained Budget Relative to Scope' : 'Budget Adequacy',
    description: tight
      ? `At ${formatCurrency(input.budget)} against a ${input.timelineWeeks}-week timeline and a ${input.teamSize}-person team, the effective spend rate (~${formatCurrency(Math.round(costPerPersonWeek))}/person/week) is thin for a project of this complexity. There is limited room to absorb scope creep, rework, or unplanned specialist support without a budget conversation.`
      : `The ${formatCurrency(input.budget)} budget provides reasonable coverage for a ${input.teamSize}-person team over ${input.timelineWeeks} weeks. The primary exposure is contingency planning rather than a fundamental shortfall.`,
    recommendation: tight
      ? `Secure a formal contingency reserve of 10-15% of total budget (approximately ${formatCurrency(Math.round(input.budget * 0.125))}) before kickoff, and put monthly burn-rate reviews in place so overruns surface early rather than at the end.`
      : `Maintain a standard 8-10% contingency reserve and review actuals against plan at each milestone to keep the budget conversation proactive.`,
  };
}

function assessTimeline(input: ProjectInput): CategoryAssessment {
  const weeksPerComplexityUnit = input.timelineWeeks / Math.max(input.complexity, 1);

  let probability: number;
  if (weeksPerComplexityUnit < 2) probability = 5;
  else if (weeksPerComplexityUnit < 3.5) probability = 4;
  else if (weeksPerComplexityUnit < 5.5) probability = 3;
  else if (weeksPerComplexityUnit < 8) probability = 2;
  else probability = 1;

  const impact = clamp(input.complexity + (input.methodology === 'Waterfall' ? 1 : 0), 1, 5);
  const tight = probability >= 4;

  return {
    category: 'Timeline',
    probability: toRating(probability),
    impact: toRating(impact),
    title: tight ? 'Aggressive Delivery Timeline' : 'Timeline Realism',
    description: tight
      ? `A ${input.timelineWeeks}-week schedule for a project rated ${input.complexity}/5 on complexity leaves little slack for the ${input.projectType.toLowerCase()} work involved. Any early delay compounds quickly with minimal buffer before the committed date.`
      : `The ${input.timelineWeeks}-week timeline is proportionate to the project's ${input.complexity}/5 complexity rating, leaving a workable buffer for normal schedule variance.`,
    recommendation: tight
      ? `Build a formal schedule buffer of 15-20% into the critical path, and define 2-3 hard go/no-go checkpoints so schedule risk is visible to sponsors well before the deadline, not at it.`
      : `Confirm the critical path with the delivery team and keep a standing 1-2 week buffer ahead of the final milestone.`,
  };
}

function assessScope(input: ProjectInput): CategoryAssessment {
  const probability = input.complexity;
  const impact = clamp(input.complexity + (input.methodology === 'Waterfall' ? 1 : 0), 1, 5);
  const high = probability >= 4;

  return {
    category: 'Scope',
    probability: toRating(probability),
    impact: toRating(impact),
    title: high ? 'Scope Complexity and Stability' : 'Scope Clarity',
    description: high
      ? `At a self-assessed complexity of ${input.complexity}/5, "${input.projectName || 'this project'}" carries meaningful requirements risk. ${input.methodology} delivery ${input.methodology === 'Waterfall' ? 'offers limited room to absorb scope changes once underway' : 'helps absorb some scope evolution, but complexity of this level still needs firm boundaries'}.`
      : `Complexity is rated ${input.complexity}/5, suggesting the scope is reasonably well understood and unlikely to require major rebaselining.`,
    recommendation: high
      ? `Lock a clearly scoped MVP/phase-one definition before execution begins, and route all scope changes through a lightweight but mandatory change-control step.`
      : `Maintain a living requirements backlog and revisit scope boundaries at each phase gate to catch drift early.`,
  };
}

function assessStakeholder(input: ProjectInput): CategoryAssessment {
  let probability: number;
  if (input.stakeholderCount >= 10) probability = 5;
  else if (input.stakeholderCount >= 7) probability = 4;
  else if (input.stakeholderCount >= 5) probability = 3;
  else if (input.stakeholderCount >= 3) probability = 2;
  else probability = 1;

  const impact = clamp(probability - (input.methodology === 'Agile' ? 1 : 0), 1, 5);
  const high = probability >= 4;

  return {
    category: 'Stakeholder',
    probability: toRating(probability),
    impact: toRating(impact),
    title: high ? 'Stakeholder Alignment Complexity' : 'Stakeholder Coordination',
    description: high
      ? `With ${input.stakeholderCount} stakeholders involved, competing priorities and slower consensus-building are likely, especially at decision points that affect scope, budget, or timeline.`
      : `A stakeholder group of ${input.stakeholderCount} is manageable and unlikely to create significant coordination overhead on its own.`,
    recommendation: high
      ? `Stand up a RACI matrix before kickoff and establish a biweekly steering committee cadence with a named decision-maker for each major approval area, to prevent stalled decisions.`
      : `Confirm a single accountable decision-maker and keep stakeholders aligned through concise, regular status updates.`,
  };
}

function assessResource(input: ProjectInput): CategoryAssessment {
  const demand = input.complexity * 2; // 2-10
  const ratio = demand / Math.max(input.teamSize, 1);

  let probability: number;
  if (ratio >= 2.5) probability = 5;
  else if (ratio >= 1.8) probability = 4;
  else if (ratio >= 1.2) probability = 3;
  else if (ratio >= 0.8) probability = 2;
  else probability = 1;

  const impact = clamp(Math.round((probability + input.complexity) / 2), 1, 5);
  const stretched = probability >= 4;

  return {
    category: 'Resource',
    probability: toRating(probability),
    impact: toRating(impact),
    title: stretched ? 'Team Capacity Constraints' : 'Resource Sufficiency',
    description: stretched
      ? `A ${input.teamSize}-person team against a complexity rating of ${input.complexity}/5 suggests the team is stretched thin. Key-person dependency and burnout risk both rise when capacity is this tight relative to workload.`
      : `Team size of ${input.teamSize} appears proportionate to the ${input.complexity}/5 complexity rating, with reasonable headroom for normal workload variance.`,
    recommendation: stretched
      ? `Identify and cross-train backups for any single points of failure on the team, and pre-negotiate a surge-staffing or contractor option in case capacity becomes a blocker.`
      : `Maintain current staffing and revisit capacity if scope or timeline shifts materially.`,
  };
}

function assessDependency(input: ProjectInput): CategoryAssessment {
  let probability: number;
  if (input.externalDependencies >= 6) probability = 5;
  else if (input.externalDependencies >= 4) probability = 4;
  else if (input.externalDependencies >= 2) probability = 3;
  else if (input.externalDependencies >= 1) probability = 2;
  else probability = 1;

  const impact = clamp(probability - (input.methodology === 'Agile' ? 0 : 0), 1, 5);
  const high = probability >= 4;

  return {
    category: 'Dependency',
    probability: toRating(probability),
    impact: toRating(impact),
    title: high ? 'External Dependency Exposure' : 'Dependency Footprint',
    description: high
      ? `${input.externalDependencies} external dependencies (vendors, third-party systems, or other teams) sit on the critical path, and none of them are under this team's direct control — any single delay upstream can cascade into the delivery date.`
      : `${input.externalDependencies} external ${input.externalDependencies === 1 ? 'dependency is' : 'dependencies are'} manageable with standard vendor coordination practices.`,
    recommendation: high
      ? `Maintain a live dependency log with named owners and committed dates for each external party, and schedule integration checkpoints early enough to surface delays before they threaten the critical path.`
      : `Confirm delivery commitments from each external party in writing and check in at each major milestone.`,
  };
}

function assessDelivery(input: ProjectInput): CategoryAssessment {
  const methodologyBase = input.methodology === 'Waterfall' ? 4 : input.methodology === 'Hybrid' ? 3 : 2;
  const probability = clamp(methodologyBase + (input.complexity >= 4 ? 1 : 0), 1, 5);
  const impact = clamp(input.budget >= 250000 ? 5 : input.budget >= 100000 ? 4 : 3, 1, 5);
  const elevated = probability >= 4;

  return {
    category: 'Delivery',
    probability: toRating(probability),
    impact: toRating(impact),
    title: elevated ? 'Delivery Methodology Fit' : 'Delivery Predictability',
    description: elevated
      ? `${input.methodology} delivery combined with a ${input.complexity}/5 complexity rating increases the odds that issues surface late rather than early, since ${input.methodology === 'Waterfall' ? 'validation happens mostly at the end of each phase' : 'the mixed cadence can blur ownership of continuous testing and integration'}.`
      : `${input.methodology} delivery is well-suited to a project of this complexity, supporting reasonably predictable, incremental delivery.`,
    recommendation: elevated
      ? `Introduce interim validation checkpoints (working demos, integration tests, or phase reviews) at least every 2-3 weeks so issues surface while they're still cheap to fix.`
      : `Continue the current delivery cadence and keep retrospectives active to catch process friction early.`,
  };
}

function assessGovernance(input: ProjectInput): CategoryAssessment {
  const probability = clamp(Math.round((input.stakeholderCount + input.externalDependencies) / 4) + (input.methodology === 'Waterfall' ? 1 : 0), 1, 5);
  const impact = clamp(probability, 1, 5);
  const high = probability >= 4;

  return {
    category: 'Governance',
    probability: toRating(probability),
    impact: toRating(impact),
    title: high ? 'Governance and Decision Rights' : 'Governance Structure',
    description: high
      ? `With ${input.stakeholderCount} stakeholders and ${input.externalDependencies} external dependencies in play, unclear decision rights or reporting cadence could slow down the approvals this project will need.`
      : `The stakeholder and dependency footprint is small enough that a lightweight governance structure should be sufficient.`,
    recommendation: high
      ? `Define and publish decision rights (who approves scope, budget, and schedule changes) before kickoff, along with a clear escalation path for blocked decisions.`
      : `Keep a simple status-reporting cadence in place and confirm who owns sign-off for major changes.`,
  };
}

function buildTopRisks(input: ProjectInput): TopRisk[] {
  const assessments = [
    assessBudget(input),
    assessTimeline(input),
    assessScope(input),
    assessStakeholder(input),
    assessResource(input),
    assessDependency(input),
    assessDelivery(input),
    assessGovernance(input),
  ];

  // Rank by severity (probability * impact) descending, then keep the 7 most
  // material risks — mirroring the real prompt's "5-7 risks, most severe
  // first" instruction, and dropping only the single least material one so
  // the risk matrix stays richly populated for a demo.
  const ranked = assessments
    .map((a) => ({ ...a, product: a.probability * a.impact }))
    .sort((a, b) => b.product - a.product)
    .slice(0, 7);

  return ranked.map((a) => ({
    title: a.title,
    category: a.category,
    description: a.description,
    probability: a.probability,
    impact: a.impact,
    severity: severityFromRatings(a.probability, a.impact),
    recommendation: a.recommendation,
  }));
}

function buildExecutiveSummary(input: ProjectInput, score: number, riskLevel: RiskLevel, topRisks: TopRisk[]): string {
  const name = input.projectName || 'This project';
  const primary = topRisks[0];
  const secondary = topRisks[1];

  const openings: Record<RiskLevel, string> = {
    Low: `${name} presents a healthy risk profile overall, with an overall risk score of ${score}/100.`,
    Medium: `${name} carries a moderate risk profile, with an overall risk score of ${score}/100 that warrants regular monitoring rather than immediate intervention.`,
    High: `${name} carries an elevated risk profile, with an overall risk score of ${score}/100 driven primarily by ${primary.category.toLowerCase()} and ${secondary.category.toLowerCase()} exposure.`,
    Critical: `${name} is at a critical risk level, scoring ${score}/100, and requires prompt attention from sponsors before further commitments are made.`,
  };

  return `${openings[riskLevel]} The most material concern is ${primary.title.toLowerCase()}, closely followed by ${secondary.title.toLowerCase()}. Given the ${input.methodology.toLowerCase()} delivery approach, a ${input.teamSize}-person team, and ${input.externalDependencies} external ${input.externalDependencies === 1 ? 'dependency' : 'dependencies'} over a ${input.timelineWeeks}-week timeline, the recommended path forward is to address the top risks below before locking further downstream commitments. With focused mitigation over the next few weeks, this project's risk profile is manageable and does not require fundamentally rescoping the effort.`;
}

function buildNextActions(input: ProjectInput, topRisks: TopRisk[]): string[] {
  const [first, second, third] = topRisks;
  const actions: string[] = [
    `Review and act on the "${first.title}" finding with the project sponsor this week — this is the single highest-severity item in the assessment.`,
    `Address "${second.title}" by assigning a clear owner and a target resolution date within the next sprint or phase.`,
  ];

  if (third) {
    actions.push(`Schedule a working session on "${third.title}" with the relevant leads before the next status checkpoint.`);
  }

  actions.push(
    `Confirm budget and timeline contingency reserves with the sponsor for "${input.projectName || 'this project'}" before further commitments are made.`,
    `Stand up (or confirm) a recurring steering committee cadence to track the ${input.stakeholderCount} stakeholders and ${input.externalDependencies} external ${
      input.externalDependencies === 1 ? 'dependency' : 'dependencies'
    } identified in this assessment.`,
    `Re-run this risk assessment after the next milestone to confirm mitigation steps are reducing the overall score.`
  );

  return actions;
}

/**
 * Generates a complete, input-aware mock RiskAnalysisResult for Demo Mode.
 * Every figure and recommendation is derived from the actual ProjectInput
 * so the UI showcases realistically, without requiring an API key.
 */
export function generateMockAnalysis(input: ProjectInput): RiskAnalysisResult {
  const topRisks = buildTopRisks(input);

  // Overall score blends the category-level severities (as 0-100 each) with
  // equal weighting, then nudges toward the single worst risk so one severe
  // category can't be fully diluted by several mild ones.
  const categoryScores = topRisks.map((r) => (r.probability * r.impact * 100) / 25);
  const average = categoryScores.reduce((sum, s) => sum + s, 0) / categoryScores.length;
  const worst = Math.max(...categoryScores);
  const overallRiskScore = clamp(Math.round(average * 0.65 + worst * 0.35), 4, 97);

  const riskLevel = scoreToRiskLevel(overallRiskScore);
  const projectHealth = overallRiskScore < 30 ? 'Healthy' : overallRiskScore < 65 ? 'Attention Needed' : 'Critical';

  return {
    overallRiskScore,
    riskLevel,
    executiveSummary: buildExecutiveSummary(input, overallRiskScore, riskLevel, topRisks),
    topRisks,
    projectHealth,
    nextActions: buildNextActions(input, topRisks),
  };
}
