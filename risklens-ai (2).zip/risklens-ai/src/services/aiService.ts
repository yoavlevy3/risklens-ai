import { ProjectInput } from '@/types/project';
import { RiskAnalysisResult } from '@/types/risk';
import { SYSTEM_PROMPT, buildAnalysisPrompt } from '@/lib/prompts';
import { generateMockAnalysis } from './mockAnalysis';

export type AiProvider = 'anthropic' | 'openai' | 'gemini';

export interface AiConfig {
  provider: AiProvider;
  apiKey: string;
  /** Optional override, e.g. 'claude-sonnet-4-6', 'gpt-4o', or 'gemini-2.5-pro' */
  model?: string;
}

const DEFAULT_MODELS: Record<AiProvider, string> = {
  anthropic: 'claude-sonnet-4-6',
  openai: 'gpt-4o',
  gemini: 'gemini-2.5-pro',
};

const PROVIDER_LABELS: Record<AiProvider, string> = {
  anthropic: 'Anthropic',
  openai: 'OpenAI',
  gemini: 'Google Gemini',
};

/** How long Demo Mode "thinks" before returning mock data, so the loading state feels real. */
const DEMO_MODE_DELAY_MS = 3000;

function wait(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/** Thrown for any failure in the analysis pipeline; `userMessage` is safe to show in the UI. */
export class AiServiceError extends Error {
  userMessage: string;
  cause?: unknown;
  constructor(userMessage: string, cause?: unknown) {
    super(userMessage);
    this.name = 'AiServiceError';
    this.userMessage = userMessage;
    this.cause = cause;
  }
}

/**
 * Strips markdown code fences and any leading/trailing prose the model may
 * have added despite instructions, then parses the JSON payload.
 */
function extractJson(raw: string): unknown {
  let text = raw.trim();
  text = text.replace(/^```(?:json)?\s*/i, '').replace(/```\s*$/i, '');

  const firstBrace = text.indexOf('{');
  const lastBrace = text.lastIndexOf('}');
  if (firstBrace === -1 || lastBrace === -1 || lastBrace < firstBrace) {
    throw new AiServiceError('The AI response did not contain valid JSON output.');
  }
  const jsonSlice = text.slice(firstBrace, lastBrace + 1);

  try {
    return JSON.parse(jsonSlice);
  } catch (err) {
    throw new AiServiceError('The AI response could not be parsed. Please try analyzing again.', err);
  }
}

/** Minimal structural validation so a malformed AI response fails loudly instead of rendering broken UI. */
function validateResult(data: unknown): RiskAnalysisResult {
  if (typeof data !== 'object' || data === null) {
    throw new AiServiceError('The AI returned an unexpected response format.');
  }
  const d = data as Record<string, unknown>;
  const requiredKeys = [
    'overallRiskScore',
    'riskLevel',
    'executiveSummary',
    'topRisks',
    'projectHealth',
    'nextActions',
  ];
  for (const key of requiredKeys) {
    if (!(key in d)) {
      throw new AiServiceError(`The AI response was missing required field: ${key}.`);
    }
  }
  if (!Array.isArray(d.topRisks) || d.topRisks.length === 0) {
    throw new AiServiceError('The AI response did not include any identified risks.');
  }
  if (!Array.isArray(d.nextActions) || d.nextActions.length === 0) {
    throw new AiServiceError('The AI response did not include next actions.');
  }
  return d as unknown as RiskAnalysisResult;
}

async function callAnthropic(config: AiConfig, userPrompt: string): Promise<string> {
  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': config.apiKey,
      'anthropic-version': '2023-06-01',
      // Required for direct browser calls to the Anthropic API (no backend proxy in this MVP).
      'anthropic-dangerous-direct-browser-access': 'true',
    },
    body: JSON.stringify({
      model: config.model || DEFAULT_MODELS.anthropic,
      max_tokens: 4000,
      system: SYSTEM_PROMPT,
      messages: [{ role: 'user', content: userPrompt }],
    }),
  });

  if (!response.ok) {
    const errBody = await safeReadError(response);
    throw new AiServiceError(mapHttpError(response.status, errBody, PROVIDER_LABELS.anthropic));
  }

  const json = await response.json();
  const textBlock = json?.content?.find((b: { type: string }) => b.type === 'text');
  if (!textBlock?.text) {
    throw new AiServiceError('The AI returned an empty response.');
  }
  return textBlock.text as string;
}

async function callOpenAi(config: AiConfig, userPrompt: string): Promise<string> {
  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${config.apiKey}`,
    },
    body: JSON.stringify({
      model: config.model || DEFAULT_MODELS.openai,
      max_tokens: 4000,
      response_format: { type: 'json_object' },
      messages: [
        { role: 'system', content: SYSTEM_PROMPT },
        { role: 'user', content: userPrompt },
      ],
    }),
  });

  if (!response.ok) {
    const errBody = await safeReadError(response);
    throw new AiServiceError(mapHttpError(response.status, errBody, PROVIDER_LABELS.openai));
  }

  const json = await response.json();
  const content = json?.choices?.[0]?.message?.content;
  if (!content) {
    throw new AiServiceError('The AI returned an empty response.');
  }
  return content as string;
}

async function callGemini(config: AiConfig, userPrompt: string): Promise<string> {
  const model = config.model || DEFAULT_MODELS.gemini;
  const response = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(
      config.apiKey
    )}`,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        systemInstruction: {
          role: 'system',
          parts: [{ text: SYSTEM_PROMPT }],
        },
        contents: [
          {
            role: 'user',
            parts: [{ text: userPrompt }],
          },
        ],
        generationConfig: {
          temperature: 0.4,
          maxOutputTokens: 4000,
          responseMimeType: 'application/json',
        },
      }),
    }
  );

  if (!response.ok) {
    const errBody = await safeReadError(response);
    throw new AiServiceError(mapHttpError(response.status, errBody, PROVIDER_LABELS.gemini));
  }

  const json = await response.json();

  // Gemini can stop early (e.g. MAX_TOKENS, SAFETY) without a usable candidate.
  const candidate = json?.candidates?.[0];
  const finishReason = candidate?.finishReason;
  const text = candidate?.content?.parts?.map((p: { text?: string }) => p.text || '').join('') || '';

  if (!text) {
    if (finishReason === 'SAFETY' || finishReason === 'RECITATION') {
      throw new AiServiceError('Gemini declined to generate a response for this input. Try adjusting the project notes and analyzing again.');
    }
    throw new AiServiceError('The AI returned an empty response.');
  }

  return text;
}

async function safeReadError(response: Response): Promise<string> {
  try {
    const body = await response.json();
    return body?.error?.message || body?.message || JSON.stringify(body);
  } catch {
    return response.statusText;
  }
}

function mapHttpError(status: number, body: string, provider: string): string {
  if (status === 401 || status === 403) {
    return `Your ${provider} API key was rejected. Please check the key and try again.`;
  }
  if (status === 429) {
    return `${provider} rate limit reached. Please wait a moment and try again.`;
  }
  if (status >= 500) {
    return `${provider} is currently unavailable. Please try again shortly.`;
  }
  return `${provider} request failed: ${body}`;
}

export interface AnalysisResponse {
  result: RiskAnalysisResult;
  /** True when no API key was configured and the result is simulated mock data. */
  isDemo: boolean;
}

/**
 * Main entry point: sends the project input to the configured AI provider
 * and returns a validated, structured risk analysis result.
 *
 * Demo Mode: if no API key is configured, this does NOT throw. Instead it
 * simulates a realistic analysis delay and returns a comprehensive mock
 * result derived from the project inputs, so the full UI can be showcased
 * without requiring anyone to bring their own API key.
 */
export async function analyzeProjectRisk(input: ProjectInput, config: AiConfig): Promise<AnalysisResponse> {
  if (!config.apiKey.trim()) {
    await wait(DEMO_MODE_DELAY_MS);
    return { result: generateMockAnalysis(input), isDemo: true };
  }

  const userPrompt = buildAnalysisPrompt(input);

  let rawText: string;
  try {
    if (config.provider === 'anthropic') {
      rawText = await callAnthropic(config, userPrompt);
    } else if (config.provider === 'gemini') {
      rawText = await callGemini(config, userPrompt);
    } else {
      rawText = await callOpenAi(config, userPrompt);
    }
  } catch (err) {
    if (err instanceof AiServiceError) throw err;
    if (err instanceof TypeError) {
      // Typically a network/CORS failure
      throw new AiServiceError(
        'Could not reach the AI provider. Check your internet connection and API key, and note that some corporate networks block direct API calls.',
        err
      );
    }
    throw new AiServiceError('An unexpected error occurred while analyzing the project.', err);
  }

  const parsed = extractJson(rawText);
  return { result: validateResult(parsed), isDemo: false };
}
